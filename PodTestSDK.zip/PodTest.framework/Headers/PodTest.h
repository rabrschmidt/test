//
//  PodTest.h
//  PodTest
//
//  Created by Robin Schmidt on 12.02.19.
//  Copyright © 2019 RockAByte GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PodTest.
FOUNDATION_EXPORT double PodTestVersionNumber;

//! Project version string for PodTest.
FOUNDATION_EXPORT const unsigned char PodTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PodTest/PublicHeader.h>

#import <PodTest/PodTestSDK.h>
